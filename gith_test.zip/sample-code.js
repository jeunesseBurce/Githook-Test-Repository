var sample = function(){
        
    console.log('sample code to be pushed using githooks (gith)');
};