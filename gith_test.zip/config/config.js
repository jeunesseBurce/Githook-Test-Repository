'use strict';

var path = require('path'), 

    config = {
        NAME_APP: 'Githook Repo Test',
        PORT: 5143
    };