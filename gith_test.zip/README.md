# Githook-Test-Repository
This is a repository created to test Githooks

# Installing hooks

  Remove ".sample" extension from the filenames under the .git/hooks directory
  
  
  To make hooks executable, use **chmod + x .git/hooks/[filename]**

# Scripts

 This is written in different scripts tailored to fit different os, scripts are written in 
 shell script, batch file, python and node. 
 
# Resolving Conflicts
  
  Install available merge tools in git i.e. **kdiff3, vimdiff and diffmerge** to edit and resolve conflicts
  during automatic merging in githooks
